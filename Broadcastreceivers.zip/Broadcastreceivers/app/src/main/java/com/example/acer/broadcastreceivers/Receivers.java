package com.example.acer.broadcastreceivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class Receivers extends BroadcastReceiver {
    public static final String CUSTOM_BROADCAST="com.example.acer.broadcastreceivers.custom_broadcast";

    @Override
    public void onReceive(Context context, Intent intent) {
        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        String action=intent.getAction();
        switch (action)

        {
            case CUSTOM_BROADCAST:
                Toast.makeText(context, "custom_broadcast", Toast.LENGTH_SHORT).show();
                break;
            case Intent.ACTION_POWER_CONNECTED:
                Toast.makeText(context, "", Toast.LENGTH_SHORT).show();
                break;
            case Intent.ACTION_BATTERY_CHANGED:
                Toast.makeText(context, "", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}
